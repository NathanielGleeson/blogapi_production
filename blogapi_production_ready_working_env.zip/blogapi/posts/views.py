from django.contrib.auth import get_user_model  
from rest_framework import viewsets
from rest_framework.permissions import IsAdminUser

from .models import Post 
from .permissions import IsAuthorOrReadOnly
from .serializers import PostSerializer, UserSerializer

class PostViewSet(viewsets.ModelViewSet):
    permmission_classes = (IsAuthorOrReadOnly,)
    queryset = Post.objects.all()
    serializer_class = PostSerializer


#class PostDetail(generics.RetrieveUpdateDestroyAPIView):
    
    #to restrict the detail view to only admin users implement next line
    #permission_classes = (permissions.IsAdminUser,)
    
   # permission_classes = (IsAuthorOrReadOnly,)
   # queryset = Post.objects.all()
  #  serializer_class = PostSerializer

class UserViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAdminUser]
    queryset = get_user_model().objects.all()
    serializer_class = UserSerializer

#class UserDetail(generics.RetrieveUpdateDestroyAPIView):
    #queryset = get_user_model().objects.all()
    #serializer_class = UserSerializer